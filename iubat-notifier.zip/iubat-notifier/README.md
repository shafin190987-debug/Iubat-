# IUBAT Notice Tracker — Setup Guide
## Sends you a WhatsApp message when a new notice is posted on iubat.edu

---

## STEP 1 — Get WhatsApp API Access (Free)

1. Go to: https://developers.facebook.com
2. Click **"Get Started"** and log in with a Facebook account
3. Click **"Create App"** → choose **"Business"** → give it any name (e.g. "IUBAT Tracker")
4. On the app dashboard, find **"WhatsApp"** and click **"Set up"**
5. You'll see a **"Getting Started"** page — this gives you:
   - ✅ A **Temporary Access Token** (valid 24hrs for testing)
   - ✅ A **Phone Number ID**
   - ✅ A free test WhatsApp number

6. Under **"To"**, add YOUR WhatsApp number (with country code, e.g. `8801XXXXXXXXX`)
7. Click **"Send Message"** to verify it works — you should receive a test WhatsApp

> For permanent token (recommended): Go to Business Settings → System Users → Create a system user → Generate a permanent token with `whatsapp_business_messaging` permission.

---

## STEP 2 — Upload to GitHub

1. Go to: https://github.com and create a free account (if you don't have one)
2. Click the **"+"** icon → **"New repository"**
3. Name it `iubat-notifier`, set it to **Private**, click **Create**
4. Click **"uploading an existing file"**
5. Upload these 3 files:
   - `main.py`
   - `requirements.txt`
   - `Procfile`
6. Click **"Commit changes"**

---

## STEP 3 — Deploy on Railway (Free)

1. Go to: https://railway.app
2. Click **"Start a New Project"** → **"Deploy from GitHub repo"**
3. Sign in with your GitHub account and select `iubat-notifier`
4. Railway will detect the project automatically — click **Deploy**

---

## STEP 4 — Set Environment Variables

In Railway, click your project → **"Variables"** tab → add these one by one:

| Variable Name        | Value                              |
|---------------------|------------------------------------|
| WHATSAPP_TOKEN      | Your WhatsApp Access Token         |
| WHATSAPP_PHONE      | Your number e.g. `8801XXXXXXXXX`   |
| WHATSAPP_PHONE_ID   | Your Phone Number ID from Meta     |
| CHECK_INTERVAL      | `300` (= check every 5 minutes)    |

Click **"Save"** — Railway will automatically restart with the new variables.

---

## STEP 5 — Watch it run!

- Click the **"Deployments"** tab in Railway
- Click your deployment → **"View Logs"**
- You'll see output like:
  ```
  [2026-03-15 10:00:00] 🚀 IUBAT Notice Tracker started
  [2026-03-15 10:00:01] 📌 First run — saving 10 notices as baseline
  [2026-03-15 10:05:01] ✓ No new notices
  ```
- When a new notice is posted, you'll get a WhatsApp like:
  ```
  🎓 IUBAT Notice Alert — 1 new notice!
  📋 Important Notice for Spring 2026
  📅 2026-03-15
  🔗 https://iubat.edu/...
  ```

---

## Notes

- Railway free tier gives you $5 credit/month which is more than enough for this bot
- The script checks every 5 minutes by default (change CHECK_INTERVAL to adjust)
- It remembers which notices it already sent, so no duplicate messages
